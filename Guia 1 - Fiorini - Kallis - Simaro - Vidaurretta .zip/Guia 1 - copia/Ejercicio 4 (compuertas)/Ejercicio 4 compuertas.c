#include <Ejercicio 4 compuertas.h>

#fuses INTRC_IO   // Utilizo oscilador interno con pines RA6 y RA7 como GPIO
#fuses NOMCLR     // Desactivo el MCLR
#fuses NOWDT      // Desactivo el watchdog

// DEFINICION DE FUNCIONES
void InitGPIO(void); //inicializo los puesrtos


/*Realizar un programa que permita contar de 0 a 255, y que vaya
mostrando el resultado en 8 leds conectados al puerto B. Utilizar la funci�n delay
cada 200ms.*/


//MAIN
void main()
{
int i;

   InitGPIO();

   while(TRUE) {
      for(i=0; i<=255; i++) {
         output_b(i);       // Mando el valor en binario a PORTB
         delay_ms(200);     // Espero 200 ms
      }
   }
}

//INICIALIZACION DE FUNCIONES
void InitGPIO(void) {
setup_adc_ports(NO_ANALOGS);
 set_tris_b(0b00000000); //todo como salidas
 output_b(0x00); //inicializo en 0 (x hexa)
}
