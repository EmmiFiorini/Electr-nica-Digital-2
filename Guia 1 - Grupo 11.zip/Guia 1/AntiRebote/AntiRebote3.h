#include <16F1827.h>
#device ADC=10
#use delay(internal=4MHz)

