#include <Ejercicio3_timers.h>

#fuses INTRC_IO   // Utilizo oscilador interno con pines RA6 y RA7 como GPIO
#fuses NOMCLR     // Desactivo el MCLR
#fuses NOWDT      // Desactivo el watchdog

/*****************************************************************************
 * Funciones de Inicializacion de Perifericos
 ****************************************************************************/
void InitGPIO(void);
void InitTimer0(void); //inicializo timer


int contador= 0;
int led_activo= 0; // 1= led encendido esperando a que pasen los 500ms


//INTERRUPCIONES
#INT_TIMER0
void TIMER0_ISR() {
   if (led_activo) {
   contador++; 
      if (contador >= 8) {  //despues de 8 "vueltas", aprox 524 ms
         output_low(PIN_B2); 
         led_activo=0; 
         contador=0; 
      }
   }
}

#INT_RB 
void RB_ISR(void){
// Si se detecta alg�n cambio en RB4-RB7 y el LED no esta activo
   if((input(PIN_B4) || input(PIN_B5) || input(PIN_B6) || input(PIN_B7)) && !led_activo) {
      output_high(PIN_B2); //prendo LED
      led_activo=1; 
      contador=0; 
   
   }
}

/*****************************************************************************
 * Main
 ****************************************************************************/

void main(void) { 

   InitGPIO(); // Inicializo PORTB
   InitTimer0();
   
   while(TRUE) { 
   
   }
}

void InitGPIO(void){ 
      set_tris_b(0b10111111); // RB2 salida, resto entradas 
      output_low(PIN_B2); // LED apagado al inicio 
      
      //habilito interrupciones 
      enable_interrupts(INT_RB); //habilita interrupcion
      enable_interrupts(GLOBAL); //habilita interrupciones globales
}

void InitTimer0(void){
   setup_timer_0(RTCC_INTERNAL | RTCC_8_BIT | RTCC_DIV_256); // Timer0 interno con prescaler maximo
   set_timer0(0); // precarga inicial
   enable_interrupts(INT_TIMER0);
   enable_interrupts(GLOBAL);
}




