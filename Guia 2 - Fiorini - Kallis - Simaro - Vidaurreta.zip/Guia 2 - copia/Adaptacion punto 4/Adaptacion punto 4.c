#include <Adaptacion punto 4.h>


#fuses INTRC_IO   // Oscilador interno con pines RA6 y RA7 como GPIO
#fuses NOMCLR     // Desactivo el MCLR
#fuses NOWDT      // Desactivo el watchdog

/*****************************************************************************
 * LCD
 ****************************************************************************/
#include <lcd.c>

#define LCD_ENABLE_PIN  PIN_A0
#define LCD_RS_PIN      PIN_A1
//#define LCD_RW_PIN      PIN_A2 // CONECTADO A GND SI NO LO USAMOS
#define LCD_DATA4       PIN_A4
#define LCD_DATA5       PIN_A5
#define LCD_DATA6       PIN_A6
#define LCD_DATA7       PIN_A7

/*Realizar una rutina que permita leer el n�mero ingresado en un teclado matricial, sin
utilizar ninguna librer�a con el objetivo de hacer uso del puerto B para la lectura del mismo,
mostrar el n�mero o car�cter en un display lcd conectado al puerto A.*/

/*****************************************************************************
 * Funciones de Inicializacion de Perifericos
 ****************************************************************************/

void Init_GPIO(void);
void Init_ADC(void);
void InitTimer0(void);


/*****************************************************************************
* Estados
****************************************************************************/
typedef enum {
   ESPERAR,     // Espero que se presione una tecla
   MOSTRAR      // Muestro la tecla en el LCD
} eEstado;

eEstado estado_actual = ESPERAR;
/*****************************************************************************
* Variables globales
****************************************************************************/
char tecla = 0 ; // tecla que se presiona
int fila_pins[4] = {PIN_B4, PIN_B5, PIN_B6, PIN_B7};
int col_pins[3] = {PIN_B0, PIN_B1, PIN_B2};

/* ADC */
int16 resultado_adc=0;
int flag_adc = 0;


/* TIMER 0 */
int contador_ms = 0;
int flag_segundo = 0;

/*****************************************************************************
* Interrupciones
****************************************************************************/

#INT_TIMER0 // ACA ESCRIBO QU� DEBO HACER EN CADA INTERRUPCI�N
void Timer0_ISR() {
  
  set_timer0(61);
  if(contador_ms >= 20) { //PASO 1 SEG
       contador_ms = 0;
       flag_segundo = 1; // aviso que ya pas� el tiempo deseado
   }
   contador_ms++;
}


#INT_AD
void ISR_ADC(void) {
   resultado_adc = read_adc(ADC_READ_ONLY);
   flag_adc = 1;
   
}

/*****************************************************************************
* Teclado
****************************************************************************/

char teclado[4][3] = {{'1','2','3'},
                      {'4','5','6'},
                      {'7','8','9'},
                      {'*','0','#'}};

/*****************************************************************************
* Funciones
****************************************************************************/
char read_keypad(void);
void maquina(void);

void main()
{

Init_GPIO();
lcd_init();
Init_ADC();
InitTimer0();

   while(TRUE) {
      maquina();
   }

}

void Init_GPIO()
{
/* SETEAMOS LOS PINES PB0-PB7 COMO SALIDA */
   set_tris_b(0b00001111); //RB0-RB2 = entrada, columnas, RB4-RB7 = Filas, salidas
   set_tris_a(0b00000000); // TODO COMO SALIDA EN ESTADO BAJO 
   
   port_b_pullups(TRUE);
   
   output_high(PIN_B4);
   output_high(PIN_B5);
   output_high(PIN_B6);
   output_high(PIN_B7);
   
   output_low(PIN_A1);
   output_low(PIN_A2);
   output_low(PIN_A0);
   output_low(PIN_A4);
   output_low(PIN_A5);
   output_low(PIN_A6);
   output_low(PIN_A7);
   
   enable_interrupts(INT_EXT);
   enable_interrupts(GLOBAL);
}

void Init_ADC() {

setup_adc_ports(sAN0);
setup_adc(ADC_CLOCK_INTERNAL);
set_adc_channel(0);
enable_interrupts(INT_AD);

}

void InitTimer0(void) {

    setup_timer_0(RTCC_INTERNAL|RTCC_DIV_256); // Configuro prescaler
    
    set_timer0(61);                  // Reinicio el timer --> Interrupciones cada 50ms
    enable_interrupts(INT_TIMER0);    // Activo Interrupcion timer0
    
}


char read_keypad(void) {
   int fila;
   int col;
   for(fila=0; fila<4; fila++) {
         output_high(PIN_B4);
         output_high(PIN_B5);
         output_high(PIN_B6);
         output_high(PIN_B7);          // Todas filas en 1
         output_low(fila_pins[fila]);    // Activar una fila en 0

      for(col=0; col<3; col++) {
         if(!input(col_pins[col])) // si se presiono alguna tecla la col tmb 0
            return teclado[fila][col];
      }
   }
   return 0; // nada presionado
}

void maquina() {
   switch(estado_actual) {
         case ESPERAR:
            read_adc(ADC_START_ONLY); // SIEMPRE ESTOY LEYENDO HASTA PERO ESPERO AL BOT�N
            tecla = read_keypad();       // leo teclado
     
            if(tecla != 0 && flag_adc == 1) {   
               estado_actual = MOSTRAR;// si presionaron algo, no hay 0 en el teclado
            }
           
     
         break;
   
         case MOSTRAR:
            if(flag_segundo == 1) {
               lcd_putc('\f'); // borrar LCD
               lcd_putc("\f");
               printf(LCD_PUTC ,resultado_adc);
               flag_segundo = 0;
               flag_adc = 0;
               estado_actual = ESPERAR;     // volver a esperar
         }
         break;
   }
}
