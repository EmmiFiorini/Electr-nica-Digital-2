#include <Punto4guia2.h>

#fuses INTRC_IO   // Oscilador interno con pines RA6 y RA7 como GPIO
#fuses NOMCLR     // Desactivo el MCLR
#fuses NOWDT      // Desactivo el watchdog


/*****************************************************************************
 * LCD
 ****************************************************************************/
#include <lcd.c>

#define LCD_ENABLE_PIN PIN_A0
#define LCD_RS_PIN     PIN_A1
//#define LCD_RW_PIN   PIN_A2   // CONECTADO A GND SI NO LO USAMOS
#define LCD_DATA4 PIN_A4
#define LCD_DATA5 PIN_A5
#define LCD_DATA6 PIN_A6
#define LCD_DATA7 PIN_A7


/*****************************************************************************
 * Estados de la m�quina
 ****************************************************************************/
typedef enum {
   ESPERAR,   // Espero que se presione una tecla
   MOSTRAR    // Muestro la tecla en el LCD
} eEstado;

eEstado estado_actual = ESPERAR;

/*****************************************************************************
 * Variables globales
 ****************************************************************************/
char tecla = 0;   // tecla que se presiona
int fila_pins[4] = {PIN_B4, PIN_B5, PIN_B6, PIN_B7};
int col_pins[3]  = {PIN_B0, PIN_B1, PIN_B2};

/*****************************************************************************
 * Teclado (matriz 4x3)
 ****************************************************************************/
char teclado[4][3] = {
   {'1','2','3'},
   {'4','5','6'},
   {'7','8','9'},
   {'*','0','#'}
};

/*****************************************************************************
 * Prototipos
 ****************************************************************************/
void Init_GPIO(void);
char read_keypad(void);
void maquina(void);

/*****************************************************************************
 * MAIN
 ****************************************************************************/
void main() {
   Init_GPIO();
   lcd_init();
   lcd_putc("\fListo"); // Mensaje inicial

   while(TRUE) {
      maquina();
   }
}

/*****************************************************************************
 * Inicializaci�n de GPIO
 ****************************************************************************/
void Init_GPIO() {
   // RB0-RB2 = entradas (columnas), RB4-RB7 = salidas (filas)
   set_tris_b(0b00000111);
   set_tris_a(0b00000000); // Puerto A como salida

   port_b_pullups(TRUE);   // Pull-up internos en RB0-RB2

   // Inicializo filas en alto
   output_high(PIN_B4);
   output_high(PIN_B5);
   output_high(PIN_B6);
   output_high(PIN_B7);
}

/*****************************************************************************
 * Lectura del teclado
 ****************************************************************************/
char read_keypad(void) {
   int fila, col;

   for(fila=0; fila<4; fila++) {
      // Pongo todas las filas en 1
      output_high(PIN_B4);
      output_high(PIN_B5);
      output_high(PIN_B6);
      output_high(PIN_B7);

      // Activo UNA fila poni�ndola en 0
      output_low(fila_pins[fila]);

      // Recorro columnas
      for(col=0; col<3; col++) {
         if(!input(col_pins[col])) { // si columna baja => tecla presionada
            delay_ms(20); // anti-rebote simple
            while(!input(col_pins[col])); // espero que suelte la tecla
            return teclado[fila][col];
         }
      }
   }
   return 0; // nada presionado
}

/*****************************************************************************
 * M�quina de estados
 ****************************************************************************/
void maquina() {
   switch(estado_actual) {
      case ESPERAR:
         tecla = read_keypad(); // leo teclado
         if(tecla != 0) {
            estado_actual = MOSTRAR;
         }
         break;

      case MOSTRAR:
         lcd_putc('\f');   // borrar LCD
         lcd_putc(tecla);  // mostrar tecla
         estado_actual = ESPERAR;
         break;
   }
}

