#include <Ejercicio4_TP2.h>

#fuses INTRC_IO   // Oscilador interno con pines RA6 y RA7 como GPIO
#fuses NOMCLR     // Desactivo el MCLR
#fuses NOWDT      // Desactivo el watchdog

/*****************************************************************************
 * LCD
 ****************************************************************************/
#include <lcd.c>
#define LCD_ENABLE_PIN  PIN_A0
#define LCD_RS_PIN      PIN_A1
//#define LCD_RW_PIN      PIN_A2 // CONECTADO A GND SI NO LO USAMOS
#define LCD_DATA4       PIN_A4
#define LCD_DATA5       PIN_A5
#define LCD_DATA6       PIN_A6
#define LCD_DATA7       PIN_A7



/*****************************************************************************
 * Funciones de Inicializacion de Perifericos
 ****************************************************************************/

void Init_GPIO();

/*****************************************************************************
* Estados
****************************************************************************/
typedef enum {
   ESPERAR,     // Espero que se presione una tecla
   MOSTRAR      // Muestro la tecla en el LCD
} eEstado;

eEstado estado_actual = ESPERAR;
/*****************************************************************************
* Variables globales
****************************************************************************/
char tecla = 0 ; // tecla que se presiona
int fila_pins[4] = {PIN_B4, PIN_B5, PIN_B6, PIN_B7};
int col_pins[3] = {PIN_B0, PIN_B1, PIN_B2};

/*****************************************************************************
* Teclado
****************************************************************************/

char teclado[4][3] = {{'1','2','3'},
                      {'4','5','6'},
                      {'7','8','9'},
                      {'*','0','#'}};

/*****************************************************************************
* Funciones
****************************************************************************/
char read_keypad(void);
void maquina(void);

void main()
{

Init_GPIO();
lcd_init();

   while(TRUE) {
   maquina();
   }

}

void Init_GPIO()
{
/* SETEAMOS LOS PINES PB0-PB7 COMO SALIDA */
   set_tris_b(0b00000111); //RB0-RB2 = entrada, columnas, RB4-RB7 = Filas, salidas
   set_tris_a(0b00000000); // TODO COMO SALIDA EN ESTADO BAJO 
   
   port_b_pullups(TRUE);
   
   output_high(PIN_B4);
   output_high(PIN_B5);
   output_high(PIN_B6);
   output_high(PIN_B7);
   
   output_low(PIN_A1);
   output_low(PIN_A2);
   output_low(PIN_A0);
   output_low(PIN_A4);
   output_low(PIN_A5);
   output_low(PIN_A6);
   output_low(PIN_A7);
}

char read_keypad(void) {
   int fila;
   int col;
   for(fila=0; fila<4; fila++) {
         output_high(PIN_B4);
         output_high(PIN_B5);
         output_high(PIN_B6);
         output_high(PIN_B7);          // Todas filas en 1
         output_low(fila_pins[fila]);    // Activar una fila en 0

      for(col=0; col<3; col++) {
         if(!input(col_pins[col])) // si se presiono alguna tecla la col tmb 0
            return teclado[fila][col];
      }
   }
   return 0; // nada presionado
}

void maquina() {
   switch(estado_actual) {
         case ESPERAR:
            tecla = read_keypad();       // leo teclado
            if(tecla != 0) {             // si presionaron algo, no hay 0 en el teclado
               estado_actual = MOSTRAR;
            }
         break;
   
         case MOSTRAR:
            lcd_putc('\f'); // borrar LCD
            lcd_putc(tecla);  // mostrar tecla
            estado_actual = ESPERAR;     // volver a esperar
         break;
   }
}
