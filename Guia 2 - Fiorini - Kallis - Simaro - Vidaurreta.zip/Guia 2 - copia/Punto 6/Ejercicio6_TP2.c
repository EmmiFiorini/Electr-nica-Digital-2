#include <Ejercicio6_TP2.h>


#fuses INTRC_IO   // Oscilador interno con pines RA6 y RA7 como GPIO
#fuses NOMCLR     // Desactivo el MCLR
#fuses NOWDT      // Desactivo el watchdog

/*****************************************************************************
 * LCD
 ****************************************************************************/

#define LCD_ENABLE_PIN  PIN_B1
#define LCD_RS_PIN      PIN_B2
#define LCD_RW_PIN      PIN_B3 // CONECTADO A GND SI NO LO USAMOS
#define LCD_DATA4       PIN_B4
#define LCD_DATA5       PIN_B5
#define LCD_DATA6       PIN_B6
#define LCD_DATA7       PIN_B7

#include <lcd.c>


/*****************************************************************************
 * Funciones de Inicializacion de Perifericos
 ****************************************************************************/

void Init_GPIO(void);
void Init_ADC(void);
void InitTimer0(void);

/*****************************************************************************
* Estados
****************************************************************************/
typedef enum {
    ESCRITURA,
    LECTURA, 
    //STAND_BY
} eEstado;

eEstado estado_actual = LECTURA; //eEstado estado_actual=STAND_BY;

/*****************************************************************************
* Funciones
****************************************************************************/

void maquina(void);


/*****************************************************************************
* Variables globales
****************************************************************************/

/* ADC */
int16 resultado_adc=0;
int flag_adc = 0;

/* INTERRUPCIONES EXTERNAS */
int flag_RB0 = 0;

/* TIMER 0 */
int contador_ms = 0;
int flag_segundo = 0;

/*****************************************************************************
* Interrupciones
****************************************************************************/

#INT_TIMER0 // ACA ESCRIBO QU� DEBO HACER EN CADA INTERRUPCI�N
void Timer0_ISR() {
  
  set_timer0(61);
  if(contador_ms >= 20) { //PASO 1 SEG
       contador_ms = 0;
       flag_segundo = 1; // aviso que ya pas� el tiempo deseado
   }
   contador_ms++;
}

#INT_EXT
void EXT_ISR(void) {
 
 flag_RB0 = 1;
}

#INT_AD
void ISR_ADC(void) {
   resultado_adc = read_adc(ADC_READ_ONLY);
   flag_adc = 1;
   
}

/*****************************************************************************
* Main
****************************************************************************/
void main()
{

Init_GPIO();
lcd_init();
Init_ADC();
InitTimer0();

   while(TRUE) {
      maquina();
   }

}

void Init_GPIO()
{
/* SETEAMOS LOS PINES PB0-PB7 COMO SALIDA */

   set_tris_b(0b00000001);
   set_tris_a(0b00000001);
   
   output_low(PIN_B1);
   output_low(PIN_B2);
   output_low(PIN_B3);
   output_low(PIN_B4);
   output_low(PIN_B5);
   output_low(PIN_B6);
   output_low(PIN_B7);
   
   output_low(PIN_A1);
   output_low(PIN_A2);
   output_low(PIN_A3);
   output_low(PIN_A4);
   output_low(PIN_A5);
   output_low(PIN_A6);
   output_low(PIN_A7);
   
   enable_interrupts(INT_EXT);
   enable_interrupts(GLOBAL);
}

void maquina(void) {

 switch(estado_actual) {
  
  case LECTURA:
     
     read_adc(ADC_START_ONLY); // SIEMPRE ESTOY LEYENDO HASTA PERO ESPERO AL BOT�N
     
      if(flag_RB0 == 1 && flag_adc == 1) {   
         estado_actual = ESCRITURA;
       }
  break;

  case ESCRITURA:
    
    if(flag_segundo == 1) {
      lcd_putc("\f");
      printf(LCD_PUTC,"Pot = %ld",resultado_adc);
      flag_segundo = 0;
      flag_adc = 0;
      flag_RB0 = 0;
      estado_actual = LECTURA;
    }
  break;
  
  default:
  estado_actual = LECTURA;

 }
}

void Init_ADC() {

setup_adc_ports(sAN0);
setup_adc(ADC_CLOCK_INTERNAL);
set_adc_channel(0);
enable_interrupts(INT_AD);

}

void InitTimer0(void) {

    setup_timer_0(RTCC_INTERNAL|RTCC_DIV_256); // Configuro prescaler
    
    set_timer0(61);                  // Reinicio el timer --> Interrupciones cada 50ms
    enable_interrupts(INT_TIMER0);    // Activo Interrupcion timer0
    
}

