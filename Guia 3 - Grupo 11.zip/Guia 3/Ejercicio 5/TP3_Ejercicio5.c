#include <TP3_Ejercicio5.h>

#fuses INTRC_IO   // Oscilador interno con pines RA6 y RA7 como GPIO
#fuses NOMCLR     // Desactivo el MCLR
#fuses NOWDT      // Desactivo el watchdog

/*****************************************************************************
 * LCD
 ****************************************************************************/

#define LCD_ENABLE_PIN  PIN_A0
#define LCD_RS_PIN      PIN_A1
#define LCD_RW_PIN      PIN_A2 // CONECTADO A GND SI NO LO USAMOS
#define LCD_DATA4       PIN_A3
#define LCD_DATA5       PIN_A4
#define LCD_DATA6       PIN_A5
#define LCD_DATA7       PIN_A6

#include <lcd.c>

/*****************************************************************************
 * I2C
 ****************************************************************************/
#define MAX128_ADDR_W 0x52 // Direccion I2C del MAX128 (Write)
#define MAX128_ADDR_R 0x53 // Direccion I2C del MAX128 (Read)

#use i2c(MASTER, SCL=PIN_B4, SDA=PIN_B1, FAST=400) // Configuraci�n I2C

/*****************************************************************************
 * Funciones de Inicializacion de Perifericos
 ****************************************************************************/

void InitTimer0(void);
void Init_GPIO(void);
int16 leer_max128_channel(int channel);


/*****************************************************************************
* Variables globales
****************************************************************************/

/* ADC */
int16 resultado_adc = 0;
int16 dx_val = 0;
int16 dy_val = 0;
int16 dz_val = 0;

/* TIMER 0 */
int contador_ms = 0;
int flag_segundo = 0;

/*****************************************************************************
* Interrupciones
****************************************************************************/

#INT_TIMER0 // ACA ESCRIBO QU� DEBO HACER EN CADA INTERRUPCI�N
void Timer0_ISR() {
  
  set_timer0(61); // 50 ms
  
  if(contador_ms >= 4) { //PASO 200 ms
       contador_ms = 0;
       flag_segundo = 1; // aviso que ya pas� el tiempo deseado
   }
   contador_ms++;
}


/*****************************************************************************
* Funciones
****************************************************************************/

void main()
{
   Init_GPIO();
   lcd_init();
   InitTimer0();
   
   lcd_putc('\f');     
   lcd_gotoxy(1, 1);
   printf(LCD_PUTC, "ADC"); 
       
    while(TRUE) {
        if (flag_segundo == 1) {
            lcd_putc('\f');  
            dx_val = leer_max128_channel(0x8c); 
            dy_val = leer_max128_channel(0xcc); 
            dz_val = leer_max128_channel(0xfc);
            // Actualizaci�n de LCD
            lcd_gotoxy(1, 2);
            printf(lcd_putc, "DX=%4lu", dx_val);
            delay_ms(500);
            lcd_gotoxy(1, 2);
            printf(lcd_putc, "DY=%4lu", dy_val);
            delay_ms(500);
            lcd_gotoxy(1, 2);
            printf(lcd_putc, "DZ=%4lu", dz_val);
            delay_ms(500);
            flag_segundo = 0; // Limpiar el flag
            }
    }
}
void InitTimer0(void) {

    setup_timer_0(RTCC_INTERNAL|RTCC_DIV_256); // Configuro prescaler
    set_timer0(61);               // Reinicio el timer 
    enable_interrupts(INT_TIMER0);    // Activo Interrupcion timer0
    enable_interrupts(GLOBAL);
    
}

void Init_GPIO()
{   
   setup_adc_ports(NO_ANALOGS);
   set_tris_a(0b00000000); 
   set_tris_b(0b00010010);
   
   enable_interrupts(GLOBAL);
}

// Funcion para leer un canal del MAX128 y devolver un valor de 12 bits (0-4095)
    int16 leer_max128_channel(int8 control_byte) {
    int8 msb, lsb; // Most y Least Significant Bit

    //  Iniciar conversi�n
    i2c_start();
    i2c_write(MAX128_ADDR_W);       // Direcci�n de escritura
    i2c_write(control_byte);        // Env�o del byte de control
    i2c_start();
    i2c_write(MAX128_ADDR_R);
    msb = i2c_read(1);
    lsb = i2c_read(0);
    i2c_stop();

    // Ensamblar y ajustar la justificaci�n a 12 bits
    resultado_adc = make16(msb, lsb); // El valor devuelto es un entero que representa la lectura anal�gica ( son 8 de msb y 8 de lsb )
      return resultado_adc/16; // Desplaza el valor ensamblado 4 bits a la derecha para eliminar los 4 que sobran al final 
}


