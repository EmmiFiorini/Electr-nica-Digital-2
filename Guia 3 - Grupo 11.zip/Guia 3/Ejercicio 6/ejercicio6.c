#include <ejercicio6.h>

#fuses INTRC_IO, NOWDT, NOMCLR


// CONFIGURACI�N I2C 
#use i2c(MASTER, SDA=PIN_B1, SCL=PIN_B4, FAST=100000)

// direcci�n del LM75 (A0�A2 a GND)
#define LM75_ADDR 0x90// 10010000--> 0=w y 1=r

// CONFIGURACI�N UART
#use rs232(baud=9600, xmit=PIN_A0, rcv=PIN_A1, bits=8, parity=N, stop=1)

//LCD 
#define I2C_LCD_DIR 0x40 //defino las compuertas del LCD
#define LCD_RS  0x01
#define LCD_RW  0x02
#define LCD_EN  0x04

#include <lcd.c>

// FUNCIONES

void lcd_enviar_4bits(int8 nibble, int1 es_texto);
void lcd_comando(int8 comando);
void lcd_texto(char letra);
void lcd_iniciar(void);
void lcd_mostrar_float(float num);
float leer_temperatura_LM75(void);
void InitTimer0(void); 
void maquina(void);

// VARIABLES
   /*Timer0*/
int contador_ms=0; 
int flag_segundo=0; //para el timer



//INTERRUPCIONES
//TIMER 0 
#INT_TIMER0 // ACA ESCRIBO QU� DEBO HACER EN CADA INTERRUPCI�N
void Timer0_ISR() {
  set_timer0(61);//seteo
  contador_ms++; //incremento
  
  if(contador_ms >= 20) { //PASO 1 SEG
       contador_ms = 0;
       flag_segundo = 1; // aviso que ya pas� el tiempo deseado
   }
}


void main() {
   //inicializo
   lcd_iniciar();// inicializo LCD
   InitTimer0(); // inicializo Timer0
   
   
   //imprimo la intro
   lcd_comando(0x80); // cursor al inicio
   printf(lcd_texto, "TEMP LM75 I2C");// mensaje inicial
   printf("\r\n--- Lectura LM75 ---\r\n");
   
   float temperatura=0; //creo una variable y la inicializo

   while(TRUE) {
      //maquina();

      if (flag_segundo ==1 ) { //si paso 1s 
         flag_segundo = 0;
         //flag_adc = 0;
         temperatura = leer_temperatura_LM75();   // leo temperatura del sensor
   
         // mostrar en LCD
         lcd_comando(0xC0);// segunda l�nea
         printf(lcd_texto, "Temp: ");
         lcd_mostrar_float(temperatura);
         printf(lcd_texto, " C");

      // mostrar por UART
      printf("\r\nTemperatura: %.2f C", temperatura);
      }
     }
   }


void InitTimer0(void){ 
    setup_timer_0(RTCC_INTERNAL | RTCC_DIV_256); //prescaler 1:256
    set_timer0(61);// valor inicial (50 ms)
    enable_interrupts(INT_TIMER0);// habilito interrupci�n Timer0
    enable_interrupts(GLOBAL);//habilito interrupciones globales
}


// FUNCIONES I2C PARA EL LCD


void lcd_enviar_4bits(int8 nibble, int1 es_texto) {
   
   int8 byte_i2c;
   byte_i2c = (nibble << 4);
   if(es_texto) byte_i2c |= LCD_RS;
   i2c_write(byte_i2c | LCD_EN); // Sube el pin EN
   delay_us(10);
   i2c_write(byte_i2c & ~LCD_EN); //bajo el Enable
   delay_us(40); //pauso el LCD
   
}

void lcd_comando(int8 comando) {
   
   
    i2c_start();//empiezo a hablar
    i2c_write(I2C_LCD_DIR);//direccion LCD
    lcd_enviar_4bits(comando >> 4, 0); //4 bits m�s significativos
    lcd_enviar_4bits(comando, 0);//4 bits menos significativos
    i2c_stop();//termine de comunicar
    delay_ms(2);
}

void lcd_texto(char letra) {

   
   i2c_start();//inicio la comunicacion
   i2c_write(I2C_LCD_DIR); //digo a quien le hablo (LCD)
   lcd_enviar_4bits(letra>>4,1);//envio los 4 MSB
   lcd_enviar_4bits(letra,1);//envio los 4 LSB
   i2c_stop();
}

void lcd_iniciar(void) {
   delay_ms(15);
   lcd_enviar_4bits(0x03, 0);
   delay_ms(5);
   lcd_enviar_4bits(0x03, 0);
   delay_us(100);
   lcd_enviar_4bits(0x03, 0);
   delay_us(100);
   lcd_enviar_4bits(0x02, 0);
   delay_us(100);

   lcd_comando(0x28);
   lcd_comando(0x0C);
   lcd_comando(0x06);
   lcd_comando(0x01);
   delay_ms(2);
}

// funci�n para mostrar un n�mero flotante en el LCD
void lcd_mostrar_float(float num) {
   int8 entero = (int8)num;
   int8 decimales = (int8)((num - entero) * 100);
   printf(lcd_texto, "%02u.%02u", entero, decimales);
}


// LECTURA DE TEMPERATURA (LM75)

float leer_temperatura_LM75(void) {
   int8 msb, lsb;
   float temperatura;

   i2c_start();
   i2c_write(LM75_ADDR);     // direcci�n + bit de escritura
   i2c_write(0x00);          // registro de temperatura
   i2c_start();              // repetir start para leer
   i2c_write(LM75_ADDR | 1); // direcci�n + bit de lectura
   msb = i2c_read();         // 
   lsb = i2c_read(0);        //  �ltimo byte
   i2c_stop();

   // LM75: 9 bits -> cada bit = 0.5�C
   temperatura = (float)msb;
   if(lsb & 0x80) temperatura += 0.5;

   return temperatura;
}


